# Operations guide

This document collects practical guidance on running, maintaining and
scaling the agentic RAG system in production.

## Monitoring and observability

* **Application Insights:** All back‑end requests are traced with
  correlation IDs. Use the Azure portal to monitor request rates,
  latency distributions and error rates. Configure alerts for
  sustained failures (e.g. HTTP 5xx > 1 % for 5 minutes) and high
  response times.
* **Log Analytics:** Search, filter and aggregate logs across
  components using Kusto Query Language (KQL). Useful queries include
  identifying slow queries, high memory usage or repeated ingestion
  failures.
* **Custom metrics:** The API exposes a `/health` endpoint for basic
  liveness. Future enhancements could include a `/metrics` endpoint
  emitting Prometheus or OpenTelemetry metrics (e.g. cache hit rate,
  retrieval latency, embedding latency).

## Scaling guidelines

* **Search service:** Increase replicas to improve query throughput
  (read operations) and partitions to increase capacity. Each
  additional replica doubles the service cost. Monitor CPU usage and
  latency to determine when to scale.
* **Container Apps:** Adjust CPU and memory for the API based on
  concurrency. Enable autoscaling rules based on HTTP queue length or
  CPU utilisation.
* **Redis:** The Basic C0 cache is non‑redundant. For production,
  choose a Standard tier (C1 or higher) for high availability and
  persistence. Monitor cache hit ratios and consider increasing
  capacity if items are being evicted frequently.

## Quota management

* **OpenAI quotas:** Each deployment has tokens per minute and
  requests per minute quotas. Monitor usage and request quota
  increases through the Azure portal when consistently reaching
  thresholds. The “global batch” API can offload large embedding jobs
  at lower cost【149509871357114†L720-L771】.
* **AI Search limits:** The free tier supports a limited number of
  documents and indexes. Standard tiers impose limits on vector
  dimensions and document count. Plan sharding strategies or deploy
  multiple search services if necessary.

## Maintenance tasks

* **Index rebuilds:** When your vectoriser or chunking strategy
  changes, reingest your documents. The ingestion service assigns new
  IDs per chunk; old chunks can be removed via a scheduled cleanup
  function.
* **Secret rotation:** Rotate keys (OpenAI, Document Intelligence,
  Search admin) at least quarterly. The Key Vault’s versioning makes
  rotation transparent to the application.
* **Dependency upgrades:** Use Dependabot or manual scanning to keep
  Python and Node packages up to date. Review changelogs for breaking
  changes, especially in Azure SDKs.

## Disaster recovery

* **Backups:** Periodically backup your AI Search index using the
  built‑in export API. Blob storage provides built‑in redundancy; you
  can enable geo‑redundant storage (GRS) for additional protection.
* **Region failover:** Deploy a secondary stack in another region
  (e.g. `westeurope`) and replicate documents and indexes using
  asynchronous tasks. Use Traffic Manager or Front Door to route
  traffic during a regional outage.

## Further reading

Refer to the Azure Well‑Architected Framework and the Microsoft Cloud
Adoption Framework for detailed operational best practices.