import React, { useState, useRef } from 'react';
import axios from 'axios';

interface Message {
  role: 'user' | 'assistant';
  content: string;
  citations?: string[];
}

const App: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const apiUrl = import.meta.env.VITE_API_URL || 'http://localhost:8000';

  const handleSend = async () => {
    if (!input.trim()) return;
    const question = input.trim();
    setMessages((msgs) => [...msgs, { role: 'user', content: question }]);
    setInput('');
    try {
      const resp = await axios.post(`${apiUrl}/query/`, { question });
      const { answer, citations } = resp.data;
      setMessages((msgs) => [...msgs, { role: 'assistant', content: answer, citations }]);
    } catch (err) {
      console.error(err);
      setMessages((msgs) => [...msgs, { role: 'assistant', content: 'Error generating answer.' }]);
    }
  };

  const handleUpload = async () => {
    const inputEl = fileInputRef.current;
    if (!inputEl || !inputEl.files || inputEl.files.length === 0) return;
    const file = inputEl.files[0];
    const formData = new FormData();
    formData.append('file', file);
    setUploading(true);
    try {
      await axios.post(`${apiUrl}/ingest/`, formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      alert('File uploaded and ingested successfully');
      inputEl.value = '';
    } catch (err) {
      console.error(err);
      alert('Failed to upload file');
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center p-4">
      <h1 className="text-3xl font-bold mb-4">Agentic RAG Demo</h1>
      <div className="w-full max-w-3xl bg-white shadow rounded p-4">
        <div className="mb-4">
          <input type="file" ref={fileInputRef} className="block w-full text-sm text-gray-500" />
          <button
            onClick={handleUpload}
            disabled={uploading}
            className="mt-2 px-4 py-2 bg-blue-600 text-white rounded disabled:opacity-50"
          >
            {uploading ? 'Uploading…' : 'Upload & Ingest'}
          </button>
        </div>
        <div className="h-64 overflow-y-auto border p-2 mb-4 bg-gray-50">
          {messages.map((msg, idx) => (
            <div key={idx} className={`mb-3 ${msg.role === 'user' ? 'text-right' : 'text-left'}`}>
              <div className={`inline-block px-3 py-2 rounded ${msg.role === 'user' ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-800'}`}
                dangerouslySetInnerHTML={{ __html: msg.content.replace(/\n/g, '<br/>') }}
              />
              {msg.citations && msg.citations.length > 0 && (
                <div className="text-xs text-gray-500">Sources: {msg.citations.join(', ')}</div>
              )}
            </div>
          ))}
        </div>
        <div className="flex space-x-2">
          <input
            className="flex-grow border rounded px-3 py-2"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') handleSend();
            }}
            placeholder="Type your question..."
          />
          <button
            className="px-4 py-2 bg-green-600 text-white rounded"
            onClick={handleSend}
          >
            Send
          </button>
        </div>
      </div>
    </div>
  );
};

export default App;