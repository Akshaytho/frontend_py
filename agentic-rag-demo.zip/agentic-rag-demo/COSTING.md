# Cost estimation

This project is designed to be as cost‑efficient as possible while still
leveraging Azure’s managed services for reliability and scalability.
The table below summarises the primary SKUs used in the Bicep
templates and their approximate monthly cost as of August 2025. Prices
vary by region; consult the Azure Pricing calculator for the most
accurate figures. All values are in US dollars and exclude taxes.

| Service | SKU | Notes | Approx. monthly cost |
| --- | --- | --- | --- |
| **Azure AI Search** | Standard (S0) | Includes vector search, semantic ranker, query rewrite; 1 replica/1 partition. | \$100–\$150 |
| **Cognitive Services – Document Intelligence** | S0 | Used for OCR on images and scanned PDFs; free tier (`F0`) offers 500 pages/month. | \$2 per 1K pages |
| **Azure Storage** | Standard LRS | Blob & table storage for raw documents and session summaries; costs scale with consumption. | \$5–\$10 |
| **Azure Cache for Redis** | Basic C0 | Provides ~250 MB cache with no SLA. Upgrade to Standard for production. | \$17 |
| **Azure Key Vault** | Standard | Stores secrets and keys; charges per 10K operations. | \$0.03–\$0.10 |
| **Application Insights** | Basic | Billed per GB of telemetry ingested. Allocate daily quota to control costs. | \$2–\$5 |
| **Azure Container Apps** | Consumption plan | Billed based on CPU/memory seconds and request count. Idle containers incur negligible cost. | \$10–\$30 |
| **Azure Static Web Apps** | Standard (S1) | Provides a custom domain and built‑in authentication. Free tier available with limited features. | \$9 |

## Additional notes

* **Azure OpenAI models:** Pricing depends on the model and deployment
  type. GPT‑4o mini and gpt‑5 mini are significantly cheaper than
  GPT‑4.1. See the [OpenAI pricing page](https://learn.microsoft.com/en-us/azure/ai-foundry/openai/how-to/pricing) for details.
* **Developer savings:** For local development you can run a vector
  database such as Qdrant in a Docker container instead of Azure AI
  Search and use an open‑source embedding model to avoid incurring
  cloud costs. The final deployment should still use Azure services to
  meet latency and scalability requirements.
* **Turn off to save:** When the system is not in use you can scale
  down replicas/partitions on the search service, stop the container
  apps and pause the static web app. See the operations guide for
  scripts to automate this.