# Security and Responsible AI

This project follows Azure security best practices and implements a
defense‑in‑depth strategy across identity, networking, data and
application layers. It also integrates Responsible AI safeguards to
mitigate misuse of the language model.

## Identity and access control

* **Managed identities** are used for the API container and front‑end
  Static Web App. These identities authenticate to Azure services such
  as Storage, Cognitive Services and AI Search without storing
  secrets in application code.
* **Key Vault** stores all secrets (OpenAI keys, Cognitive Services
  keys, etc.). Access to individual secrets is granted via Azure RBAC
  roles rather than hard‑coded access policies. Deployment scripts
  assign the `Key Vault Secrets User` role to the managed identities.
* **Entra ID authentication** protects the front‑end and API. Static
  Web Apps has built‑in authentication with social providers and Azure
  Active Directory (EasyAuth). The API can be configured to
  validate JWT tokens issued by the same authentication provider.
* **Role‑based access control:** Resource group scope roles are kept
  minimal – `Contributor` for deployment service principals and
  `Reader` for developers. The front‑end and API identities only have
  access to the specific resources they need.

## Network security

* **Public endpoints** are restricted. The Key Vault and search
  service disable public network access. Access is granted via
  private endpoints or service endpoints configured in the Bicep
  templates.
* **HTTPS everywhere:** All services are accessed over TLS. The front
  door provided by Static Web Apps terminates TLS and forwards
  requests to the API over HTTPS.
* **CORS:** The API allows requests only from the web app’s origin.
  During local development CORS is set to `*` and should be tightened
  before production.

## Data security

* **Encryption at rest:** All Azure services used (Storage, Redis,
  Cognitive Services, AI Search) encrypt data at rest by default
  using Microsoft‑managed keys. Custom key encryption can be enabled.
* **Encryption in transit:** TLS 1.2 is enforced for all endpoints.
* **PII handling:** Uploaded documents may contain sensitive
  information. Documents are stored in a private blob container and
  their embeddings only contain abstract vector data. The system does
  not store user queries or completions beyond the duration of a
  session unless explicitly configured.

## Responsible AI

* **Content filtering:** Azure OpenAI’s default `DefaultV2` content
  filtering policy is used to detect and filter harmful or
  inappropriate content【149509871357114†L829-L842】. The API does not allow
  overriding these settings without additional approval【278457983247438†L264-L281】.
* **Abuse monitoring:** Azure monitors the usage of OpenAI models for
  abuse and may throttle or block malicious requests. The front‑end
  rate‑limits requests and displays a warning when limits are
  exceeded.
* **Prompt injection defenses:** The AgentService explicitly
  instructs the model to ignore system prompts contained within
  retrieved documents and user inputs. Only the context extracted from
  trusted documents is passed to the model for grounding. Additional
  retrieval scoring thresholds trigger the fallback LLM which refuses
  to answer if the context is insufficient.

## Logging and observability

* All API requests and errors are logged to Application Insights.
* OpenTelemetry instrumentation can be enabled to emit traces and
  metrics for each agent step. Bicep templates configure diagnostic
  settings to forward logs to Log Analytics.

## Ongoing responsibilities

Security is never “done.” Regularly audit access policies, rotate
secrets, monitor for unusual activity and review the Azure security
centre recommendations. For high‑impact changes consult your
organisation’s security team and follow the Microsoft Cloud Adoption
Framework.