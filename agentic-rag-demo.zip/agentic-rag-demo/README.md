# Agentic Retrieval‑Augmented Generation on Azure

Welcome to **agentic‑rag‑demo**, a reference implementation of an end‑to‑end
agentic question answering system built entirely on Microsoft Azure. This
project accompanies the PDF lab manual *Agentic RAG on Azure — End‑to‑End
Build & Deploy (v2025)* and provides the complete source code and
infrastructure templates needed to deploy your own production‑ready RAG
application.

## Repository structure

| Path | Description |
| --- | --- |
| `/infra` | Bicep templates that deploy the Azure resources (storage, search, cognitive services, Redis, Key Vault, Application Insights, etc.). |
| `/api` | Python FastAPI service implementing file ingestion, vectorisation, hybrid search and a LangGraph‑based agentic workflow. |
| `/web` | React + Vite + TypeScript front‑end providing a chat‑style interface and file upload experience. |
| `/scripts` | Convenience scripts for one‑click deployment and smoke tests. |
| `/.github/workflows` | GitHub Actions workflows for CI/CD of infrastructure, back‑end and front‑end. |
| `COSTING.md` | Details of SKUs used, expected monthly costs and cost‑saving tips. |
| `SECURITY.md` | Security baseline, identity model and Responsible AI considerations. |
| `OPERATIONS.md` | Guidance on day‑to‑day operations, scaling and monitoring. |

## Quick start

The API and front‑end can be run locally for development. You’ll need
Python 3.11+, Node 20+, the Azure CLI and an Azure subscription with
access to the Azure OpenAI service.

1. Clone the repository:

   ```bash
   git clone https://github.com/your‑org/agentic‑rag‑demo.git
   cd agentic‑rag‑demo
   ```

2. Install API dependencies and run the service:

   ```bash
   cd api
   python -m venv .venv
   source .venv/bin/activate
   pip install -r requirements.txt
   # set environment variables – see below
   uvicorn app.main:app --reload --port 8000
   ```

3. Install front‑end dependencies and run the dev server:

   ```bash
   cd ../web
   npm install
   npm run dev
   ```

4. Open http://localhost:5173 and start chatting!

### Required environment variables

The API uses environment variables for all sensitive configuration. When
running locally, create a `.env` file in the `api` folder with the
following values (replace placeholders with your actual resource
settings):

```bash
AZURE_STORAGE_ACCOUNT_URL="https://<storage‑account>.blob.core.windows.net"
AZURE_STORAGE_CONTAINER="documents"
AZURE_SEARCH_ENDPOINT="https://<search‑service>.search.windows.net"
AZURE_SEARCH_KEY="<admin‑api‑key>"
AZURE_SEARCH_INDEX="documents"
AZURE_OPENAI_ENDPOINT="https://<openai‑resource>.openai.azure.com"
AZURE_OPENAI_KEY="<api‑key>"
AZURE_OPENAI_CHAT_DEPLOYMENT="<chat‑deployment‑name>"  # e.g. gpt‑4o
AZURE_OPENAI_EMBEDDING_DEPLOYMENT="<embedding‑deployment‑name>"  # e.g. text‑embedding‑ada‑002
AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT="https://<cognitive‑account>.cognitiveservices.azure.com"
AZURE_DOCUMENT_INTELLIGENCE_KEY="<api‑key>"
```

The deployment scripts will write these values into your Azure Container
Apps and Static Web Apps configuration automatically via Key Vault
references.

## Deploy to Azure

> **Note**: The Bicep templates provision resources in the region
> specified at deployment time (e.g. `eastus2`) and use cost‑effective
> SKUs. You must request access to the Azure OpenAI service ahead of
> time and ensure your subscription has quota for the models used.

Use the provided Bash script to create a resource group, deploy the
infrastructure and configure the application:

```bash
./scripts/deploy.sh <projectName> <subscriptionId> <region>
```

After deployment the script will output the front‑end and API URLs. A
smoke test script (`scripts/smoke_test.py`) can be run to validate the
deployment by ingesting a sample document and issuing a query.

For a detailed, step‑by‑step walkthrough of deploying via the Azure
Portal and CLI, refer to the accompanying PDF guide.

## Contributing

Pull requests are welcome! Please file an issue if you spot a bug or
have a feature request. See `OPERATIONS.md` for notes on upgrading
dependencies and deploying to production.