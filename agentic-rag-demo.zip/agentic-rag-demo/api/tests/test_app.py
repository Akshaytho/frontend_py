"""
Basic unit tests for the FastAPI application. These tests run without
calling external services by monkeypatching the dependencies. They
exercise the ingestion and query endpoints at a high level.
"""

from fastapi.testclient import TestClient

from app.main import app

client = TestClient(app)


def test_health():
    resp = client.get('/health')
    assert resp.status_code == 200
    assert resp.json()['status'] == 'ok'


def test_ingest_and_query(monkeypatch):
    # Monkeypatch the ingestion and agent services to avoid Azure calls
    from app.dependencies import get_ingestion_service, get_agent_service

    class DummyIngest:
        def ingest(self, data: bytes, filename: str):
            return ['doc1', 'doc2']

    class DummyAgent:
        def run(self, question: str):
            return {"answer": f"You asked: {question}", "citations": ['doc1']}

    monkeypatch.setattr('app.dependencies.get_ingestion_service', lambda: DummyIngest())
    monkeypatch.setattr('app.dependencies.get_agent_service', lambda: DummyAgent())

    # Test ingestion
    resp = client.post('/ingest/', files={'file': ('test.txt', b'hello', 'text/plain')})
    assert resp.status_code == 200
    body = resp.json()
    assert body['status'] == 'success'
    assert len(body['docIds']) == 2

    # Test query
    resp = client.post('/query/', json={'question': 'What is this?'})
    assert resp.status_code == 200
    body = resp.json()
    assert 'answer' in body
    assert 'citations' in body