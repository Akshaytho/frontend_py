"""
Ingestion service for the Agentic RAG solution.

This module defines the `IngestionService` class responsible for:

1. Determining the appropriate parser for each uploaded document type
   (PDF, Word, PowerPoint, plain text, CSV, image) and extracting
   raw text. For most file formats we rely on pure‑Python libraries
   (PyMuPDF for PDFs, python‑docx for Word documents, python‑pptx for
   PowerPoint and pandas for CSV). Images and scanned PDFs are sent to
   Azure Document Intelligence to perform OCR via the prebuilt
   `Read` model.
2. Chunking extracted text into semantically meaningful fragments.
   Simple fixed‑size chunking with overlap is used by default. More
   sophisticated strategies can be implemented by extending
   `_chunk_text`.
3. Generating embeddings for each chunk using the Azure OpenAI
   embeddings endpoint. The embedding dimension and model name are
   configurable via environment variables.
4. Persisting raw documents into Azure Storage and upserting chunk
   metadata and embeddings into an Azure AI Search index. The search
   index is lazily created on first use if it doesn't already exist.

The service uses Azure SDK clients with DefaultAzureCredential for
authentication. When running locally you can authenticate with the
Azure CLI (`az login`) or by setting the appropriate environment
variables. In production the container will use a managed identity.
"""

import io
import os
import uuid
from dataclasses import dataclass
from typing import Iterable, List, Tuple

import fitz  # PyMuPDF
import pandas as pd
from docx import Document as DocxDocument
from pptx import Presentation

from azure.identity import DefaultAzureCredential, ManagedIdentityCredential
from azure.search.documents import SearchClient
from azure.search.documents.indexes import SearchIndexClient
from azure.search.documents.indexes.models import (
    ComplexField,
    CorsOptions,
    SearchIndex,
    SearchField,
    SearchFieldDataType,
    SemanticSettings,
    VectorSearch,
    HnswParameters,
)
from azure.search.documents.models import Vector
from azure.core.credentials import AzureKeyCredential
from azure.storage.blob import BlobServiceClient
from azure.ai.documentintelligence import DocumentIntelligenceClient
from azure.ai.openai import OpenAIClient


def _get_default_credential() -> DefaultAzureCredential:
    """Resolve Azure credentials for local development or managed identity."""
    # Prefer managed identity if available; fall back to interactive
    # authentication. DefaultAzureCredential automatically chains
    # multiple credential types.
    return DefaultAzureCredential(exclude_interactive_browser_credential=True)


def _guess_mime_type(filename: str) -> str:
    ext = filename.lower().split('.')[-1]
    if ext in ('pdf',):
        return 'application/pdf'
    if ext in ('docx',):
        return 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    if ext in ('pptx',):
        return 'application/vnd.openxmlformats-officedocument.presentationml.presentation'
    if ext in ('txt',):
        return 'text/plain'
    if ext in ('csv',):
        return 'text/csv'
    if ext in ('png', 'jpg', 'jpeg', 'bmp'):  # image formats
        return f'image/{ext}'
    return 'application/octet-stream'


def _chunk_text(text: str, max_tokens: int = 512, overlap: int = 64) -> List[str]:
    """
    Simple token‑agnostic chunking. Splits the given text into chunks of
    approximately `max_tokens` characters with an overlap to preserve
    context. In production you should implement token‑aware chunking
    (e.g. using the `tiktoken` package) and respect semantic boundaries.
    """
    if not text:
        return []
    step = max_tokens - overlap
    chunks = []
    for start in range(0, len(text), step):
        end = min(start + max_tokens, len(text))
        chunk = text[start:end]
        chunks.append(chunk)
        if end == len(text):
            break
    return chunks


@dataclass
class IngestionConfig:
    storage_account_url: str
    storage_container: str
    search_service_endpoint: str
    search_service_key: str
    search_index_name: str
    openai_endpoint: str
    openai_embedding_model: str
    openai_api_key: str
    document_intelligence_endpoint: str
    document_intelligence_key: str


class IngestionService:
    """Service encapsulating ingestion logic for documents and vectors."""

    def __init__(self, config: IngestionConfig):
        self.config = config
        # Storage client for raw documents
        self.blob_service = BlobServiceClient(account_url=config.storage_account_url, credential=_get_default_credential())
        self.container_client = self.blob_service.get_container_client(config.storage_container)
        # Search clients for index management and document upserts
        self.search_client = SearchClient(
            endpoint=config.search_service_endpoint,
            index_name=config.search_index_name,
            credential=AzureKeyCredential(config.search_service_key),
        )
        self.search_index_client = SearchIndexClient(
            endpoint=config.search_service_endpoint,
            credential=AzureKeyCredential(config.search_service_key),
        )
        # OpenAI client for embeddings
        self.openai_client = OpenAIClient(
            endpoint=config.openai_endpoint,
            credential=AzureKeyCredential(config.openai_api_key),
        )
        # Document Intelligence client for OCR
        self.doc_intel_client = DocumentIntelligenceClient(
            endpoint=config.document_intelligence_endpoint,
            credential=AzureKeyCredential(config.document_intelligence_key),
        )
        # Ensure the search index exists
        self._ensure_search_index()

    def _ensure_search_index(self) -> None:
        """Create the search index if it does not already exist."""
        try:
            self.search_index_client.get_index(self.config.search_index_name)
            return
        except Exception:
            pass
        fields = [
            SearchField(name='id', type=SearchFieldDataType.String, key=True),
            SearchField(name='content', type=SearchFieldDataType.String, searchable=True, filterable=False, sortable=False),
            SearchField(name='fileName', type=SearchFieldDataType.String, searchable=True),
            SearchField(name='chunkIndex', type=SearchFieldDataType.Int32),
            SearchField(name='embedding', type=SearchFieldDataType.Collection(SearchFieldDataType.Single), searchable=True, vectorSearchDimensions=1536, vectorSearchConfiguration='default'),
        ]
        vector_search = VectorSearch(
            algorithms=[HnswParameters(name='default')],
        )
        index = SearchIndex(name=self.config.search_index_name, fields=fields, vectorSearch=vector_search)
        # Semantic settings may be added to enable semantic ranking
        index.semantic_settings = SemanticSettings()
        self.search_index_client.create_index(index)

    def _upload_raw_document(self, file_name: str, data: bytes) -> str:
        """Upload the raw file to blob storage and return the blob URL."""
        blob_client = self.container_client.get_blob_client(file_name)
        blob_client.upload_blob(data, overwrite=True)
        return blob_client.url

    def _extract_text(self, data: bytes, file_name: str, mime_type: str) -> str:
        """Extract raw text from supported file types."""
        if mime_type == 'application/pdf':
            # Read PDF with PyMuPDF
            with fitz.open(stream=data, filetype='pdf') as doc:
                text = "\n".join(page.get_text() for page in doc)
            return text
        elif mime_type == 'application/vnd.openxmlformats-officedocument.wordprocessingml.document':
            document = DocxDocument(io.BytesIO(data))
            paragraphs = [para.text for para in document.paragraphs]
            return "\n".join(paragraphs)
        elif mime_type == 'application/vnd.openxmlformats-officedocument.presentationml.presentation':
            presentation = Presentation(io.BytesIO(data))
            text_runs = []
            for slide in presentation.slides:
                for shape in slide.shapes:
                    if hasattr(shape, "text"):
                        text_runs.append(shape.text)
            return "\n".join(text_runs)
        elif mime_type == 'text/plain':
            return data.decode('utf-8', errors='replace')
        elif mime_type == 'text/csv':
            df = pd.read_csv(io.StringIO(data.decode('utf-8', errors='replace')))
            return df.to_csv(index=False)
        elif mime_type.startswith('image/'):
            # Use Document Intelligence to OCR images
            poller = self.doc_intel_client.begin_analyze_document('prebuilt-read', document=data)
            result = poller.result()
            lines = []
            for page in result.pages:
                for line in page.lines:
                    lines.append(line.content)
            return "\n".join(lines)
        else:
            raise ValueError(f'Unsupported file type: {mime_type}')

    def _embed_chunks(self, chunks: List[str]) -> List[List[float]]:
        """Generate embeddings for each chunk using Azure OpenAI."""
        responses = []
        # The `get_embeddings` method accepts a list of strings and returns
        # embeddings. Some versions of the SDK call this method `get_embeddings` or
        # `get_embedding`; adjust accordingly.
        for chunk in chunks:
            resp = self.openai_client.get_embeddings(
                model=self.config.openai_embedding_model,
                input=[chunk],
            )
            embedding = resp.data[0].embedding  # type: ignore[attr-defined]
            responses.append(embedding)
        return responses

    def ingest(self, data: bytes, filename: str) -> List[str]:
        """
        Ingest a single document. Returns a list of document IDs inserted
        into the search index. Each chunk is treated as a separate document
        with its own unique ID.
        """
        mime_type = _guess_mime_type(filename)
        # Upload the raw document for archival and later reprocessing
        blob_url = self._upload_raw_document(filename, data)
        # Extract text and chunk it
        text = self._extract_text(data, filename, mime_type)
        chunks = _chunk_text(text)
        embeddings = self._embed_chunks(chunks)
        documents = []
        ids = []
        for idx, (chunk, embedding) in enumerate(zip(chunks, embeddings)):
            doc_id = str(uuid.uuid4())
            doc = {
                'id': doc_id,
                'content': chunk,
                'fileName': filename,
                'chunkIndex': idx,
                'embedding': embedding,
            }
            documents.append(doc)
            ids.append(doc_id)
        # Upsert into search index in batches. Using batching improves
        # performance and reduces cost on standard tiers.
        batch_size = 1000
        for i in range(0, len(documents), batch_size):
            batch = documents[i:i + batch_size]
            self.search_client.upload_documents(batch)
        return ids