"""
Search service for the Agentic RAG solution.

This module exposes a thin wrapper around the Azure AI Search SDK. It
implements hybrid search combining vector similarity and keyword search
with semantic ranking. The returned results include the retrieved
documents and their relevance scores. Higher‑level components such as
the agent service use this to ground answers.
"""

from typing import List, Optional

from azure.core.credentials import AzureKeyCredential
from azure.search.documents import SearchClient


class SearchService:
    def __init__(self, endpoint: str, index_name: str, api_key: str):
        self.client = SearchClient(endpoint=endpoint, index_name=index_name, credential=AzureKeyCredential(api_key))

    def hybrid_search(
        self,
        query: str,
        vector: Optional[list[float]] = None,
        top_k: int = 5,
        use_semantic: bool = True,
    ) -> List[dict]:
        """
        Perform a hybrid search. If a vector is provided it will be used for
        nearest neighbour search; otherwise a purely lexical search is
        executed. The semantic ranker is enabled when available.
        """
        search_kwargs: dict = {
            "search_text": query,
            "top": top_k,
            "include_total_count": False,
        }
        if vector is not None:
            search_kwargs["vector"] = vector
            search_kwargs["vector_fields"] = "embedding"
        if use_semantic:
            search_kwargs["query_type"] = "semantic"
            # enable extractive summarization and captioning
            search_kwargs["semantic_configuration"] = "default"
        # Additional options such as queryLanguage and spellingCorrection can
        # be configured here.
        results = self.client.search(**search_kwargs)
        hits = []
        for result in results:
            hit = {
                "id": result["id"],
                "content": result["content"],
                "score": result.get("@search.score"),
                "fileName": result.get("fileName"),
                "chunkIndex": result.get("chunkIndex"),
            }
            hits.append(hit)
        return hits