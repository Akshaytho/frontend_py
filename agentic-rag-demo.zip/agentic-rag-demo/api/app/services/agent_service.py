"""
Agent service orchestrating a multi‑step retrieval‑augmented generation
workflow using LangGraph. The graph consists of several nodes:

1. **Router**: Inspect the user query and decide whether a tool call is
   required or if it's a simple Q&A task. In this simplified example the
   router always routes to retrieval.
2. **Retriever**: Execute a hybrid search against Azure AI Search to
   obtain relevant document chunks. The retriever stores the retrieved
   documents in memory for later grounding.
3. **Answerer**: Call the Azure OpenAI chat model to generate an answer
   conditioned on the retrieved documents. The answerer adds inline
   citations referencing the document IDs.
4. **Critic**: Inspect the answer for hallucinations or low
   confidence. If the answer fails validation the pipeline can either
   iterate (not implemented here) or fall back to a generic answer.

This agent service hides the complexity of building and running a
LangGraph pipeline. Clients call the `run` method with a question and
receive a final answer along with citations.
"""

import json
from typing import Any, Dict, List, Optional

from langgraph.graph import Graph
from langchain.chat_models import AzureChatOpenAI
from langchain.schema import AIMessage, HumanMessage, SystemMessage

from .search_service import SearchService


class AgentService:
    def __init__(self, search_service: SearchService, openai_client: AzureChatOpenAI):
        self.search_service = search_service
        self.llm = openai_client
        self.graph = self._build_graph()

    def _build_graph(self) -> Graph:
        graph = Graph()

        # Router node: decide the next step. For now, always go to retriever.
        def router(state: Dict[str, Any]) -> str:
            return "retriever"

        # Retriever node: perform hybrid search and store documents in state
        def retriever(state: Dict[str, Any]) -> str:
            query = state["question"]
            hits = self.search_service.hybrid_search(query, top_k=5)
            state["docs"] = hits
            return "answerer"

        # Answerer node: build a prompt using retrieved docs and call LLM
        def answerer(state: Dict[str, Any]) -> str:
            docs: List[Dict[str, Any]] = state.get("docs", [])
            citations = []
            context_blocks = []
            for doc in docs:
                context_blocks.append(f"[{doc['id']}] {doc['content']}")
                citations.append(doc['id'])
            context = "\n\n".join(context_blocks)
            prompt = (
                "You are a retrieval augmented question answering assistant. "
                "Use the following context to answer the question as truthfully as possible. "
                "If the answer is not contained in the context, say you don't know.\n\n"
                f"Context:\n{context}\n\n"
                f"Question: {state['question']}\nAnswer:"
            )
            messages = [SystemMessage(content="You are a helpful assistant."), HumanMessage(content=prompt)]
            response = self.llm(messages)
            state["answer"] = response.content
            state["citations"] = citations
            return "critic"

        # Critic node: evaluate the answer. This stub passes directly to finish.
        def critic(state: Dict[str, Any]) -> str:
            # TODO: implement actual validation logic (e.g. using another LLM
            # or heuristics). For now always finish.
            return "finish"

        graph.add_node("router", router)
        graph.add_node("retriever", retriever)
        graph.add_node("answerer", answerer)
        graph.add_node("critic", critic)
        graph.set_entry_point("router")
        graph.set_finish_point("critic")
        graph.add_edge("router", "retriever")
        graph.add_edge("retriever", "answerer")
        graph.add_edge("answerer", "critic")
        return graph

    def run(self, question: str) -> Dict[str, Any]:
        """Execute the agent pipeline for a single question."""
        state = {"question": question}
        final_state = self.graph(state)
        return {
            "answer": final_state.get("answer"),
            "citations": final_state.get("citations"),
        }