"""
FastAPI dependency providers for services. These helpers read configuration
from environment variables and instantiate long‑lived service objects.

Using dependency injection decouples the API layer from concrete service
implementations and makes unit testing easier. Environment variables are
used rather than hard‑coding secrets or connection strings in source
control. When running in Azure Container Apps or Functions the
environment variables are populated via Key Vault references and the
Azure CLI deployment scripts.
"""

import os
from functools import lru_cache
from typing import Generator

from fastapi import Depends
from langchain.chat_models import AzureChatOpenAI

from .services.ingestion_service import IngestionConfig, IngestionService
from .services.search_service import SearchService
from .services.agent_service import AgentService


@lru_cache(maxsize=1)
def get_search_service() -> SearchService:
    endpoint = os.environ['AZURE_SEARCH_ENDPOINT']
    api_key = os.environ['AZURE_SEARCH_KEY']
    index_name = os.environ['AZURE_SEARCH_INDEX']
    return SearchService(endpoint, index_name, api_key)


@lru_cache(maxsize=1)
def get_agent_service() -> AgentService:
    search_service = get_search_service()
    llm = AzureChatOpenAI(
        azure_deployment=os.environ['AZURE_OPENAI_CHAT_DEPLOYMENT'],
        azure_endpoint=os.environ['AZURE_OPENAI_ENDPOINT'],
        azure_api_key=os.environ['AZURE_OPENAI_KEY'],
        temperature=0.0,
    )
    return AgentService(search_service, llm)


@lru_cache(maxsize=1)
def get_ingestion_service() -> IngestionService:
    config = IngestionConfig(
        storage_account_url=os.environ['AZURE_STORAGE_ACCOUNT_URL'],
        storage_container=os.environ['AZURE_STORAGE_CONTAINER'],
        search_service_endpoint=os.environ['AZURE_SEARCH_ENDPOINT'],
        search_service_key=os.environ['AZURE_SEARCH_KEY'],
        search_index_name=os.environ['AZURE_SEARCH_INDEX'],
        openai_endpoint=os.environ['AZURE_OPENAI_ENDPOINT'],
        openai_embedding_model=os.environ['AZURE_OPENAI_EMBEDDING_DEPLOYMENT'],
        openai_api_key=os.environ['AZURE_OPENAI_KEY'],
        document_intelligence_endpoint=os.environ['AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT'],
        document_intelligence_key=os.environ['AZURE_DOCUMENT_INTELLIGENCE_KEY'],
    )
    return IngestionService(config)


def inject_agent_service() -> Generator[AgentService, None, None]:
    yield get_agent_service()


def inject_ingestion_service() -> Generator[IngestionService, None, None]:
    yield get_ingestion_service()