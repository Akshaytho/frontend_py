"""
API router for querying the RAG system. Accepts a question in the
request body and returns an answer with citations. The heavy lifting
is delegated to the AgentService which orchestrates retrieval and
generation using LangGraph.
"""

from typing import List

from fastapi import APIRouter, Depends
from pydantic import BaseModel

from ..dependencies import inject_agent_service
from ..services.agent_service import AgentService

router = APIRouter()


class QueryRequest(BaseModel):
    question: str


class QueryResponse(BaseModel):
    answer: str
    citations: List[str]


@router.post('/', response_model=QueryResponse)
async def query(
    request: QueryRequest,
    agent_service: AgentService = Depends(inject_agent_service),
) -> QueryResponse:
    result = agent_service.run(request.question)
    return QueryResponse(**result)