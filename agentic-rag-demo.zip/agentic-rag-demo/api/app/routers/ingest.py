"""
API router for document ingestion. Supports uploading a single file via
multipart/form‑data. The file is processed by the ingestion service
which handles text extraction, chunking, embedding and indexing. A list
of document IDs corresponding to the inserted chunks is returned to
the caller.
"""

from typing import Optional

from fastapi import APIRouter, Depends, File, UploadFile

from ..services.ingestion_service import IngestionService
from ..dependencies import inject_ingestion_service


router = APIRouter()


@router.post('/')
async def ingest_file(
    file: UploadFile = File(...),
    session_id: Optional[str] = None,
    ingestion_service: IngestionService = Depends(inject_ingestion_service),
) -> dict:
    """Handle file upload and trigger ingestion pipeline."""
    data = await file.read()
    doc_ids = ingestion_service.ingest(data, file.filename)
    return {
        "status": "success",
        "fileName": file.filename,
        "docIds": doc_ids,
    }