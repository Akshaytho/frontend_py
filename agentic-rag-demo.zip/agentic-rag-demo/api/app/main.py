"""
Entry point for the Agentic RAG API. This module constructs the FastAPI
application, configures CORS, mounts router modules and exposes a simple
health check. All business logic lives in the service and router layers.

To run the API locally during development:

```bash
uvicorn app.main:app --reload --port 8000
```

The production deployment uses Azure Container Apps or Functions; see
deployment scripts and GitHub workflows for details.
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .routers import ingest, query

app = FastAPI(
    title="Agentic RAG on Azure API",
    description="Backend service for an end‑to‑end agentic retrieval‑augmented generation solution on Azure.",
    version="0.1.0",
)

# Enable CORS for the front‑end. In production the allowed origins should be
# restricted to the deployed Static Web Apps domain; during development
# localhost origins are enabled by default.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/health")
async def health() -> dict:
    """Simple liveness probe used by the smoke tests and container orchestrators."""
    return {"status": "ok"}

# Mount routers. Each router encapsulates a set of related endpoints and
# contains its own request/response models.
app.include_router(ingest.router, prefix="/ingest", tags=["ingestion"])
app.include_router(query.router, prefix="/query", tags=["query"])