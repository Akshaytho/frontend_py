#!/usr/bin/env bash

# This script deploys the infrastructure and configures the environment for
# the agentic RAG demo. You must have the Azure CLI installed and be
# logged in. Usage:
#
#   ./deploy.sh <projectName> <subscriptionId> <region>
#
# After deployment it prints the names of the created resources and
# suggestions for next steps.

set -euo pipefail

if [ $# -lt 3 ]; then
  echo "Usage: $0 <projectName> <subscriptionId> <region>"
  exit 1
fi

PROJECT_NAME=$1
SUBSCRIPTION=$2
LOCATION=$3

echo "Setting subscription to $SUBSCRIPTION"
az account set --subscription "$SUBSCRIPTION"

RG_NAME="${PROJECT_NAME}-rg"
DEPLOYMENT_NAME="${PROJECT_NAME}-deploy"

# Create resource group
echo "Creating resource group $RG_NAME in $LOCATION"
az group create --name "$RG_NAME" --location "$LOCATION" --output none

# Deploy Bicep template
echo "Deploying core infrastructure via Bicep..."
az deployment group create \
  --resource-group "$RG_NAME" \
  --name "$DEPLOYMENT_NAME" \
  --template-file "$(dirname "$0")/../infra/main.bicep" \
  --parameters projectName="$PROJECT_NAME" location="$LOCATION" \
  --output none

echo "Deployment complete. Fetching outputs..."
STORAGE_ACCOUNT=$(az deployment group show --resource-group "$RG_NAME" --name "$DEPLOYMENT_NAME" --query "properties.outputs.storageAccountName.value" -o tsv)
SEARCH_SERVICE=$(az deployment group show --resource-group "$RG_NAME" --name "$DEPLOYMENT_NAME" --query "properties.outputs.searchServiceName.value" -o tsv)
KEY_VAULT=$(az deployment group show --resource-group "$RG_NAME" --name "$DEPLOYMENT_NAME" --query "properties.outputs.keyVaultName.value" -o tsv)
REDIS_HOST=$(az deployment group show --resource-group "$RG_NAME" --name "$DEPLOYMENT_NAME" --query "properties.outputs.redisHostName.value" -o tsv)
APPI_KEY=$(az deployment group show --resource-group "$RG_NAME" --name "$DEPLOYMENT_NAME" --query "properties.outputs.appInsightsInstrumentationKey.value" -o tsv)

echo "Resources created:"
echo "  Storage account:     $STORAGE_ACCOUNT"
echo "  Search service:      $SEARCH_SERVICE"
echo "  Key Vault:          $KEY_VAULT"
echo "  Redis cache host:   $REDIS_HOST"
echo "  App Insights key:   $APPI_KEY"

echo "Next steps:"
echo "1. Create a blob container called 'documents' in the storage account:"
echo "   az storage container create --account-name $STORAGE_ACCOUNT --name documents"
echo "2. Deploy the API container and front‑end using the GitHub Actions workflows or your preferred method."
echo "3. Populate Key Vault with the required secrets (OpenAI keys, search admin key, etc.) and configure your Container App to reference them."
echo "4. Run scripts/smoke_test.py to validate the deployment."
