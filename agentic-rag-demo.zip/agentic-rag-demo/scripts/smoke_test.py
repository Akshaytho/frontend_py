#!/usr/bin/env python3
"""
Smoke test for the Agentic RAG deployment. This script uploads a small
document to the ingestion endpoint and then issues a question to the
query endpoint. It prints the answer and citations to stdout. Run
this script after deploying the infrastructure and API by setting
`API_URL` in the environment to the base URL of your API (e.g.
https://<containerapp>.azurecontainerapps.io).
"""

import os
import sys
import time
from pathlib import Path

import requests


def main() -> None:
    api_url = os.environ.get('API_URL')
    if not api_url:
        print('API_URL environment variable not set', file=sys.stderr)
        sys.exit(1)
    ingest_endpoint = f"{api_url.rstrip('/')}/ingest/"
    query_endpoint = f"{api_url.rstrip('/')}/query/"
    # Prepare a temporary document
    sample_text = """Azure OpenAI's GPT‑4o mini model provides a fast and cost‑effective solution for retrieval‑augmented generation applications.\nThis is a test document for the smoke test."""
    file_path = Path('sample.txt')
    file_path.write_text(sample_text, encoding='utf-8')
    with file_path.open('rb') as fh:
        files = {'file': ('sample.txt', fh, 'text/plain')}
        print('Uploading sample document...')
        resp = requests.post(ingest_endpoint, files=files)
        resp.raise_for_status()
        print('Ingestion response:', resp.json())
    # Wait for indexing (may not be instantaneous on free tiers)
    print('Waiting a few seconds for indexing to complete...')
    time.sleep(10)
    question = 'What model does the document mention?'
    print('Asking question:', question)
    resp = requests.post(query_endpoint, json={'question': question})
    resp.raise_for_status()
    print('Query response:', resp.json())


if __name__ == '__main__':
    main()